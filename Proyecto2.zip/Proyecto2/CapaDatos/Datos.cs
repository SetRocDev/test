﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaDatos
{
    public class Datos
    {
        // Arreglos de objetos para la informacion

        public static ClaseCategoria[] ArregloCategoria = new ClaseCategoria[10];
        public static ClaseArticulo[] ArregloArticulo = new ClaseArticulo[20];
        public static ClaseAdministrador[] ArregloAdministrador = new ClaseAdministrador[20];
        public static ClaseSucursal[] ArregloSucursal = new ClaseSucursal[5];
        public static ClaseCliente[] ArregloCliente = new ClaseCliente[20];
        public static ClaseArticuloxSucursal[] ArregloInventario = new ClaseArticuloxSucursal[100];// inventario, articulo, cantidad

        // Contador para los arreglos

        public static int ContadorCategoria { get; set; } = 0;
        public static int ContadorArticulo { get; set; } = 0;
        public static int ContadorAdministrador { get; set; } = 0;
        public static int ContadorSucursal { get; set; } = 0;
        public static int ContadorCliente { get; set; } = 0;
        public static int ContadorArticuloxSucursal { get; set; } = 0;
    }
}