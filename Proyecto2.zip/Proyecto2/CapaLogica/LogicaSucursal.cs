﻿using CapaDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaLogica
{
    public class LogicaSucursal
    {
        // Método para guardar una sucursal
        public void GuardarSucursal(ClaseSucursal sucursal)
        {
            try
            {
                // Validar que haya espacio en el arreglo
                if (Datos.ContadorSucursal >= Datos.ArregloSucursal.Length)
                {
                    throw new Exception("No se puede guardar más información. El arreglo está lleno.");
                }

                // Validar que el Id sea único
                for (int i = 0; i < Datos.ContadorSucursal; i++)
                {
                    if (Datos.ArregloSucursal[i].IdSucursal == sucursal.IdSucursal)
                    {
                        throw new Exception("El Id de sucursal ya existe.");
                    }
                }

                // Validar que no haya campos vacíos
                if (string.IsNullOrEmpty(sucursal.NombreSucursal) || string.IsNullOrEmpty(sucursal.DireccionSucursal) || string.IsNullOrEmpty(sucursal.TelefonoSucursal))
                {
                    throw new Exception("No se puede guardar información nula.");
                }

                // Validar que el Id sea un número entero
                if (sucursal.IdSucursal < 0)
                {
                    throw new Exception("El Id de sucursal debe ser un número entero positivo.");
                }

                // Guardar la información en el arreglo
                Datos.ArregloSucursal[Datos.ContadorSucursal] = sucursal;
                Datos.ContadorSucursal++;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
