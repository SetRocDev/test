﻿using CapaDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaLogica
{
    public class LogicaAdministrador
    {
        // Método para guardar un administrador
        public void GuardarAdministrador(ClaseAdministrador administrador)
        {
            try
            {
                // Validar que haya espacio en el arreglo
                if (Datos.ContadorAdministrador >= Datos.ArregloAdministrador.Length)
                {
                    throw new Exception("No se puede guardar más información. El arreglo está lleno.");
                }

                // Validar que el Id sea único
                for (int i = 0; i < Datos.ContadorAdministrador; i++)
                {
                    if (Datos.ArregloAdministrador[i].IdAdministrador == administrador.IdAdministrador)
                    {
                        throw new Exception("El Id de administrador ya existe.");
                    }
                }

                // Validar que no haya campos vacíos
                if (string.IsNullOrEmpty(administrador.NombreAdministrador) || string.IsNullOrEmpty(administrador.Apellido1Administrador) || string.IsNullOrEmpty(administrador.Apellido2Administrador))
                {
                    throw new Exception("No se puede guardar información nula.");
                }

                // Validar que el Id sea un número entero
                if (administrador.IdAdministrador < 0)
                {
                    throw new Exception("El Id de administrador debe ser un número entero positivo.");
                }

                // Guardar la información en el arreglo
                Datos.ArregloAdministrador[Datos.ContadorAdministrador] = administrador;
                Datos.ContadorAdministrador++;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
