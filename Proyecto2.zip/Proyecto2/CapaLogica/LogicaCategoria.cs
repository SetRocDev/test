﻿using CapaDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaLogica
{
    public class LogicaCategoria
    {
        // Método para guardar una categoria
        public void GuardarCategoria(ClaseCategoria categoria)
        {
            try
            {
                // Validar que haya espacio en el arreglo
                if (Datos.ContadorCategoria >= Datos.ArregloCategoria.Length)
                {
                    throw new Exception("No se puede guardar más información. El arreglo está lleno.");
                }

                // Validar que el Id sea único
                for (int i = 0; i < Datos.ContadorCategoria; i++)
                {
                    if (Datos.ArregloCategoria[i].IdCategoria == categoria.IdCategoria)
                    {
                        throw new Exception("El Id de categoría ya existe.");
                    }
                }

                // Validar que no haya campos vacíos
                if (string.IsNullOrEmpty(categoria.NombreCategoria) || string.IsNullOrEmpty(categoria.DescripcionCategoria))
                {
                    throw new Exception("No se puede guardar información nula.");
                }

                // Validar que el Id sea un número entero
                if (categoria.IdCategoria < 0)
                {
                    throw new Exception("El Id de categoría debe ser un número entero positivo.");
                }

                // Guardar la información en el arreglo
                Datos.ArregloCategoria[Datos.ContadorCategoria] = categoria;
                Datos.ContadorCategoria++;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
