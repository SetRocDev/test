﻿using CapaDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaLogica
{
    public class LogicaCliente
    {
        // Método para guardar la información del cliente
        public void GuardarCliente(ClaseCliente cliente)
        {
            try
            {
                // Validar que haya espacio en el arreglo
                if (Datos.ContadorCliente >= Datos.ArregloCliente.Length)
                {
                    throw new Exception("No se puede guardar más información. El arreglo está lleno.");
                }

                // Validar que el Id sea único
                for (int i = 0; i < Datos.ContadorCliente; i++)
                {
                    if (Datos.ArregloCliente[i].IdentificacionCliente == cliente.IdentificacionCliente)
                    {
                        throw new Exception("El Id de cliente ya existe.");
                    }
                }

                // Validar que no haya campos vacíos
                if (string.IsNullOrEmpty(cliente.NombreCliente) || string.IsNullOrEmpty(cliente.Apellido1Cliente) || string.IsNullOrEmpty(cliente.Apellido2Cliente))
                {
                    throw new Exception("No se puede guardar información nula.");
                }

                // Validar que el Id sea un número entero
                if (cliente.IdentificacionCliente < 0)
                {
                    throw new Exception("El Id de cliente debe ser un número entero positivo.");
                }

                // Guardar la información en el arreglo
                Datos.ArregloCliente[Datos.ContadorCliente] = cliente;
                Datos.ContadorCliente++;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
