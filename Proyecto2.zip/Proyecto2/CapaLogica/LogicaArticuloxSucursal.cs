﻿using CapaDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaLogica
{
    public class LogicaArticuloxSucursal
    {
        // Método para guardar un artículo por sucursal
        public void GuardarArticuloxSucursal(ClaseArticuloxSucursal inventario)
        {
            try
            {
                // Validar que haya espacio en el arreglo
                if (Datos.ContadorArticuloxSucursal >= Datos.ArregloInventario.Length)
                {
                    throw new Exception("No se puede guardar más información. El arreglo está lleno.");
                }

                // Validar que no sea nulo el inventario
                if (inventario == null)
                {
                    throw new Exception("No se puede guardar información nula.");
                }

                // Validar que la sucursal y el artículo no sean nulos
                if (inventario.SucursalInventario == null || inventario.ArticuloInventario == null)
                {
                    throw new Exception("La sucursal y el artículo son requeridos.");
                }

                // Validar que la cantidad sea mayor a cero
                if (inventario.CantidadInventario <= 0)
                {
                    throw new Exception("La cantidad debe ser mayor a cero.");
                }

                // Validar que no exista la combinación sucursal-artículo
                for (int i = 0; i < Datos.ContadorArticuloxSucursal; i++)
                {
                    if (Datos.ArregloInventario[i] != null &&
                        Datos.ArregloInventario[i].SucursalInventario.IdSucursal == inventario.SucursalInventario.IdSucursal &&
                        Datos.ArregloInventario[i].ArticuloInventario.IdArticulo == inventario.ArticuloInventario.IdArticulo)
                    {
                        throw new Exception("Ya existe esta combinación de sucursal y artículo.");
                    }
                }

                // Guardar la información en el arreglo
                Datos.ArregloInventario[Datos.ContadorArticuloxSucursal] = inventario;
                Datos.ContadorArticuloxSucursal++;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
