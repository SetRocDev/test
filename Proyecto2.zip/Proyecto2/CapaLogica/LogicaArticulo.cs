﻿using CapaDatos;
using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaLogica
{
    public class LogicaArticulo
    {
        // Método para guardar un artículo
        public void GuardarArticulo(ClaseArticulo articulo)
        {
            try
            {
                // Validar que haya espacio en el arreglo
                if (Datos.ContadorArticulo >= Datos.ArregloArticulo.Length)
                {
                    throw new Exception("No se puede guardar más información. El arreglo está lleno.");
                }

                // Validar que el Id sea único
                for (int i = 0; i < Datos.ContadorArticulo; i++)
                {
                    if (Datos.ArregloArticulo[i].IdArticulo == articulo.IdArticulo)
                    {
                        throw new Exception("El Id de artículo ya existe.");
                    }
                }

                // Validar que no haya campos vacíos
                if (string.IsNullOrEmpty(articulo.DescripcionArticulo) || articulo.CategoriaArticulo == null || string.IsNullOrEmpty(articulo.MarcaArticulo))
                {
                    throw new Exception("No se puede guardar información nula.");
                }

                // Validar que el Id sea un número entero
                if (articulo.IdArticulo < 0)
                {
                    throw new Exception("El Id de artículo debe ser un número entero positivo.");
                }

                // Guardar la información en el arreglo
                Datos.ArregloArticulo[Datos.ContadorArticulo] = articulo;
                Datos.ContadorArticulo++;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
