﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class ClaseCliente
    {
        // Declaracion de variables.

        public int IdentificacionCliente { get; set; }
        public string NombreCliente { get; set; }
        public string Apellido1Cliente { get; set; }
        public string Apellido2Cliente { get; set; }
        public DateTime NacimientoCliente { get; set; }
        public bool ActivoCliente { get; set; }

        // Constructor de las variables.

        public ClaseCliente(int identificacionCliente, string nombreCliente, string apellido1Cliente, string apellido2Cliente, DateTime nacimientoCliente, bool activoCliente)
        {
            this.IdentificacionCliente = identificacionCliente;
            this.NombreCliente = nombreCliente;
            this.Apellido1Cliente = apellido1Cliente;
            this.Apellido2Cliente = apellido2Cliente;
            this.NacimientoCliente = nacimientoCliente;
            this.ActivoCliente = activoCliente;
        }
    }
}
