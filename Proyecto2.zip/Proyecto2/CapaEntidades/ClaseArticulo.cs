﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class ClaseArticulo
    {

        // Declaracion de variables.

        public int IdArticulo { get; set; }
        public string DescripcionArticulo { get; set; }
        public ClaseCategoria CategoriaArticulo { get; set; }
        public string MarcaArticulo { get; set; }
        public bool ActivoArticulo { get; set; }

        // Constructor de las variables.
        public ClaseArticulo(int idArticulo, string descripcionArticulo, ClaseCategoria categoriaArticulo, string marcaArticulo, bool activoArticulo)
        {
            this.IdArticulo = idArticulo;
            this.DescripcionArticulo = descripcionArticulo;
            this.CategoriaArticulo = categoriaArticulo;
            this.MarcaArticulo = marcaArticulo;
            this.ActivoArticulo = activoArticulo;
        }
    }
}
