﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class ClaseAdministrador
    {
        // Declaracion de variables.

        public int IdAdministrador { get; set; }
        public string NombreAdministrador { get; set; }
        public string Apellido1Administrador { get; set; }
        public string Apellido2Administrador { get; set; }
        public DateTime NacimientoAdministrador { get; set; }
        public DateTime IngresoAdministrador { get; set; }

        // Constructor de las variables.

        public ClaseAdministrador(int idAdministrador, string nombreAdministrador, string apellido1Administrador, string apellido2Administrador, DateTime nacimientoAdministrador, DateTime ingresoAdministrador)
        {
            this.IdAdministrador = idAdministrador;
            this.NombreAdministrador = nombreAdministrador;
            this.Apellido1Administrador = apellido1Administrador;
            this.Apellido2Administrador = apellido2Administrador;
            this.NacimientoAdministrador = nacimientoAdministrador;
            this.IngresoAdministrador = ingresoAdministrador;
        }
    }
}
