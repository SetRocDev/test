﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class ClaseArticuloxSucursal
    {

        // Declaracion de variables.
        public ClaseSucursal SucursalInventario { get; set; }
        public ClaseArticulo ArticuloInventario { get; set; }
        public int CantidadInventario { get; set; }

        // Constructor de las variables.

        public ClaseArticuloxSucursal(ClaseSucursal sucursalInventario, ClaseArticulo articuloInventario, int cantidadInventario)
        {
            this.SucursalInventario = sucursalInventario;
            this.ArticuloInventario = articuloInventario;
            this.CantidadInventario = cantidadInventario;
        }
    }
}
