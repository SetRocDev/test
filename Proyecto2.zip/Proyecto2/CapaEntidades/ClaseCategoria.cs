﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class ClaseCategoria
    {
        // Declaracion de variables.

        public int IdCategoria { get; set; }
        public string NombreCategoria { get; set; }
        public string DescripcionCategoria { get; set; }

        // Constructor de las variables.

        public ClaseCategoria(int idCategoria, string nombreCategoria, string descripcionCategoria)
        {
            this.IdCategoria = idCategoria;
            this.NombreCategoria = nombreCategoria;
            this.DescripcionCategoria = descripcionCategoria;
        }
    }
}
