﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaEntidades
{
    public class ClaseSucursal
    {

        // Declaracion de variables.

        public int IdSucursal { get; set; }
        public string NombreSucursal { get; set; }
        public ClaseAdministrador AdministradorSucursal { get; set; }
        public string DireccionSucursal { get; set; }
        public string TelefonoSucursal { get; set; }
        public bool ActivoSucursal { get; set; }

        // Constructores de las variables.
        public ClaseSucursal(int idSucursal, string nombreSucursal, ClaseAdministrador administradorSucursal, string direccionSucursal, string telefonoSucursal, bool activoSucursal)
        {
            this.IdSucursal = idSucursal;
            this.NombreSucursal = nombreSucursal;
            this.AdministradorSucursal = administradorSucursal;
            this.DireccionSucursal = direccionSucursal;
            this.TelefonoSucursal = telefonoSucursal;
            this.ActivoSucursal = activoSucursal;
        }
    }
}
