﻿using CapaDatos;
using CapaEntidades;
using CapaLogica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CapaGrafica
{
    public partial class GraficoAdministrador : Form
    {
        public GraficoAdministrador()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores de los campos de texto
                int idAdministrador;
                if (!int.TryParse(textBoxIdentificacion.Text, out idAdministrador))
                {
                    MessageBox.Show("Error al guardar el administrador: El Id de administrador debe ser un número entero.");
                    return;
                }

                // Obtener el valor del campo Activo
                string nombreAdministrador = textBoxNombre.Text ?? "";
                string apellido1Administrador = textBoxApellido1.Text ?? "";
                string apellido2Administrador = textBoxApellido2.Text ?? "";

                if (string.IsNullOrEmpty(nombreAdministrador) || string.IsNullOrEmpty(apellido1Administrador) || string.IsNullOrEmpty(apellido2Administrador))
                {
                    MessageBox.Show("Error al guardar el administrador: Debe ingresar todos los campos.");
                    return;
                }

                // Obtener la informacion de los datetimepicker
                DateTime fechaNacimientoAdministrador = dateTimePickerNacimiento.Value;
                DateTime fechaIngresoAdministrador = dateTimePickerIngreso.Value;

                ClaseAdministrador administrador = new ClaseAdministrador(idAdministrador, nombreAdministrador, apellido1Administrador, apellido2Administrador, fechaNacimientoAdministrador, fechaIngresoAdministrador);

                LogicaAdministrador logica = new LogicaAdministrador();
                logica.GuardarAdministrador(administrador);
                // Metodo para limpiar la informacion
                limpiarInfo();
                // Metodo para refresacar automaticamente el DGV
                List<ClaseAdministrador> administradores = new List<ClaseAdministrador>();

                for (int i = 0; i < Datos.ContadorAdministrador; i++)
                {
                    administradores.Add(Datos.ArregloAdministrador[i]);
                }

                dataGridView1.DataSource = administradores;
                MessageBox.Show("Administrador guardado correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el administrador: " + ex.Message);
            }
        }

        // Metodo para limpiar la informacion
        private void Refrescar_Click(object sender, EventArgs e)
        {
            List<ClaseAdministrador> administradores = new List<ClaseAdministrador>();

            for (int i = 0; i < Datos.ContadorAdministrador; i++)
            {
                administradores.Add(Datos.ArregloAdministrador[i]);
            }

            dataGridView1.DataSource = administradores;
        }
        private void limpiarInfo()
        {
            textBoxIdentificacion.Text = string.Empty;
            textBoxNombre.Text = string.Empty;
            textBoxApellido1.Text = string.Empty;
            textBoxApellido2.Text = string.Empty;
            dateTimePickerNacimiento.Text = string.Empty;
            dateTimePickerIngreso.Text = string.Empty;
        }
    }
}
