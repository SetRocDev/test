﻿using CapaDatos;
using CapaEntidades;
using CapaLogica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaGrafica
{
    public partial class GraficoCliente : Form
    {
        public GraficoCliente()
        {
            InitializeComponent();
        }

        private void GraficoCliente_Load(object sender, EventArgs e)
        {
            // Llenar el combobox de activo artículo
            comboBox1.Items.Add("Si");
            comboBox1.Items.Add("No");

            // Seleccionar el primer elemento por defecto
            if (comboBox1.Items.Count > 0)
            {
                comboBox1.SelectedIndex = 0;
            }
        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores de los campos de texto
                int identificacionCliente;
                if (!int.TryParse(textBoxIdentificacion.Text, out identificacionCliente))
                {
                    MessageBox.Show("Error al guardar el cliente: El Id de cliente debe ser un número entero.");
                    return;
                }

                // Obtener los valores de los campos de texto
                string nombreCliente = textBoxNombre.Text ?? "";
                string apellido1Cliente = textBoxApellido1.Text ?? "";
                string apellido2Cliente = textBoxApellido2.Text ?? "";

                if (string.IsNullOrEmpty(nombreCliente) || string.IsNullOrEmpty(apellido1Cliente) || string.IsNullOrEmpty(apellido2Cliente))
                {
                    MessageBox.Show("Error al guardar el cliente: Debe ingresar todos los campos.");
                    return;
                }

                // Obtener informacion de los elementos graficos
                DateTime fechaNacimientoCliente = dateTimePicker1.Value;
                string activoClienteTexto = comboBox1.Text;

                if (activoClienteTexto != "Si" && activoClienteTexto != "No")
                {
                    MessageBox.Show("Error al guardar el cliente: Debe seleccionar un valor válido para el campo Activo.");
                    return;
                }

                bool activoCliente = activoClienteTexto == "Si";

                ClaseCliente cliente = new ClaseCliente(identificacionCliente, nombreCliente, apellido1Cliente, apellido2Cliente, fechaNacimientoCliente, activoCliente);
                LogicaCliente logica = new LogicaCliente();
                logica.GuardarCliente(cliente);
                // Metodo para limpiar automaticamente
                limpiarInfo();
                // Metodo para refrescar el DGV autimaticamente
                List<ClaseCliente> clientes = new List<ClaseCliente>();

                for (int i = 0; i < Datos.ContadorCliente; i++)
                {
                    clientes.Add(Datos.ArregloCliente[i]);
                }

                dataGridView1.DataSource = clientes;

                MessageBox.Show("Cliente guardado correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el cliente: " + ex.Message);
            }
        }

        private void Volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Refrescar_Click(object sender, EventArgs e)
        {
            List<ClaseCliente> clientes = new List<ClaseCliente>();

            for (int i = 0; i < Datos.ContadorCliente; i++)
            {
                clientes.Add(Datos.ArregloCliente[i]);
            }

            dataGridView1.DataSource = clientes;
        }
        private void limpiarInfo()
        {
            textBoxIdentificacion.Text = string.Empty;
            textBoxNombre.Text = string.Empty;
            textBoxApellido1.Text = string.Empty;
            textBoxApellido2.Text = string.Empty;
            dateTimePicker1.Text = string.Empty;
            comboBox1.Text = string.Empty;
        }
    }
}
