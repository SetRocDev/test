﻿namespace CapaGrafica
{
    partial class GraficoCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textBoxIdentificacion = new TextBox();
            textBoxNombre = new TextBox();
            textBoxApellido1 = new TextBox();
            textBoxApellido2 = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            comboBox1 = new ComboBox();
            Guardar = new Button();
            Volver = new Button();
            Refrescar = new Button();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(43, 12);
            label1.Name = "label1";
            label1.Size = new Size(99, 20);
            label1.TabIndex = 0;
            label1.Text = "Identificación";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(77, 45);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 1;
            label2.Text = "Nombre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(29, 78);
            label3.Name = "label3";
            label3.Size = new Size(113, 20);
            label3.TabIndex = 2;
            label3.Text = "Primer Apellido";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(13, 111);
            label4.Name = "label4";
            label4.Size = new Size(129, 20);
            label4.TabIndex = 3;
            label4.Text = "Segundo Apellido";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(56, 146);
            label5.Name = "label5";
            label5.Size = new Size(86, 20);
            label5.TabIndex = 4;
            label5.Text = "Nacimiento";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(90, 177);
            label6.Name = "label6";
            label6.Size = new Size(51, 20);
            label6.TabIndex = 5;
            label6.Text = "Activo";
            // 
            // textBoxIdentificacion
            // 
            textBoxIdentificacion.Location = new Point(147, 9);
            textBoxIdentificacion.Name = "textBoxIdentificacion";
            textBoxIdentificacion.Size = new Size(372, 27);
            textBoxIdentificacion.TabIndex = 6;
            // 
            // textBoxNombre
            // 
            textBoxNombre.Location = new Point(147, 42);
            textBoxNombre.Name = "textBoxNombre";
            textBoxNombre.Size = new Size(372, 27);
            textBoxNombre.TabIndex = 7;
            // 
            // textBoxApellido1
            // 
            textBoxApellido1.Location = new Point(147, 75);
            textBoxApellido1.Name = "textBoxApellido1";
            textBoxApellido1.Size = new Size(372, 27);
            textBoxApellido1.TabIndex = 8;
            // 
            // textBoxApellido2
            // 
            textBoxApellido2.Location = new Point(147, 108);
            textBoxApellido2.Name = "textBoxApellido2";
            textBoxApellido2.Size = new Size(372, 27);
            textBoxApellido2.TabIndex = 9;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(148, 141);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(371, 27);
            dateTimePicker1.TabIndex = 10;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(148, 174);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(371, 28);
            comboBox1.TabIndex = 11;
            // 
            // Guardar
            // 
            Guardar.Location = new Point(604, 45);
            Guardar.Name = "Guardar";
            Guardar.Size = new Size(94, 29);
            Guardar.TabIndex = 12;
            Guardar.Text = "Guardar";
            Guardar.UseVisualStyleBackColor = true;
            Guardar.Click += Guardar_Click;
            // 
            // Volver
            // 
            Volver.Location = new Point(604, 106);
            Volver.Name = "Volver";
            Volver.Size = new Size(94, 29);
            Volver.TabIndex = 13;
            Volver.Text = "Volver";
            Volver.UseVisualStyleBackColor = true;
            Volver.Click += Volver_Click;
            // 
            // Refrescar
            // 
            Refrescar.Location = new Point(604, 168);
            Refrescar.Name = "Refrescar";
            Refrescar.Size = new Size(94, 29);
            Refrescar.TabIndex = 14;
            Refrescar.Text = "Refrescar";
            Refrescar.UseVisualStyleBackColor = true;
            Refrescar.Click += Refrescar_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(13, 208);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(775, 230);
            dataGridView1.TabIndex = 15;
            // 
            // GraficoCliente
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridView1);
            Controls.Add(Refrescar);
            Controls.Add(Volver);
            Controls.Add(Guardar);
            Controls.Add(comboBox1);
            Controls.Add(dateTimePicker1);
            Controls.Add(textBoxApellido2);
            Controls.Add(textBoxApellido1);
            Controls.Add(textBoxNombre);
            Controls.Add(textBoxIdentificacion);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "GraficoCliente";
            Text = "GraficoCliente";
            Load += GraficoCliente_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textBoxIdentificacion;
        private TextBox textBoxNombre;
        private TextBox textBoxApellido1;
        private TextBox textBoxApellido2;
        private DateTimePicker dateTimePicker1;
        private ComboBox comboBox1;
        private Button Guardar;
        private Button Volver;
        private Button Refrescar;
        private DataGridView dataGridView1;
    }
}