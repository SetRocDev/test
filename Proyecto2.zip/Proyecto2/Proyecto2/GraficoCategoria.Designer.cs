﻿namespace CapaGrafica
{
    partial class GraficoCategoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            textBoxID = new TextBox();
            textBoxCategoria = new TextBox();
            textBoxDescripcion = new TextBox();
            Guardar = new Button();
            Volver = new Button();
            dataGridView1 = new DataGridView();
            Refrescar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(74, 32);
            label1.Name = "label1";
            label1.Size = new Size(24, 20);
            label1.TabIndex = 0;
            label1.Text = "ID";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(24, 86);
            label2.Name = "label2";
            label2.Size = new Size(74, 20);
            label2.TabIndex = 1;
            label2.Text = "Categoría";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(11, 143);
            label3.Name = "label3";
            label3.Size = new Size(87, 20);
            label3.TabIndex = 2;
            label3.Text = "Descripción";
            // 
            // textBoxID
            // 
            textBoxID.Location = new Point(131, 29);
            textBoxID.Name = "textBoxID";
            textBoxID.Size = new Size(302, 27);
            textBoxID.TabIndex = 3;
            textBoxID.TextChanged += textBoxID_TextChanged;
            // 
            // textBoxCategoria
            // 
            textBoxCategoria.Location = new Point(131, 86);
            textBoxCategoria.Name = "textBoxCategoria";
            textBoxCategoria.Size = new Size(302, 27);
            textBoxCategoria.TabIndex = 4;
            textBoxCategoria.TextChanged += textBoxCategoria_TextChanged;
            // 
            // textBoxDescripcion
            // 
            textBoxDescripcion.Location = new Point(131, 140);
            textBoxDescripcion.Name = "textBoxDescripcion";
            textBoxDescripcion.Size = new Size(302, 27);
            textBoxDescripcion.TabIndex = 5;
            textBoxDescripcion.TextChanged += textBoxDescripcion_TextChanged;
            // 
            // Guardar
            // 
            Guardar.Location = new Point(510, 56);
            Guardar.Name = "Guardar";
            Guardar.Size = new Size(94, 29);
            Guardar.TabIndex = 6;
            Guardar.Text = "Guardar";
            Guardar.UseVisualStyleBackColor = true;
            Guardar.Click += Guardar_Click;
            // 
            // Volver
            // 
            Volver.Location = new Point(510, 105);
            Volver.Name = "Volver";
            Volver.Size = new Size(94, 29);
            Volver.TabIndex = 7;
            Volver.Text = "Volver";
            Volver.UseVisualStyleBackColor = true;
            Volver.Click += Volver_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(24, 207);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(753, 231);
            dataGridView1.TabIndex = 8;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Refrescar
            // 
            Refrescar.Location = new Point(510, 156);
            Refrescar.Name = "Refrescar";
            Refrescar.Size = new Size(94, 29);
            Refrescar.TabIndex = 9;
            Refrescar.Text = "Refrescar";
            Refrescar.UseVisualStyleBackColor = true;
            Refrescar.Click += Refrescar_Click;
            // 
            // GraficoCategoria
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Refrescar);
            Controls.Add(dataGridView1);
            Controls.Add(Volver);
            Controls.Add(Guardar);
            Controls.Add(textBoxDescripcion);
            Controls.Add(textBoxCategoria);
            Controls.Add(textBoxID);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "GraficoCategoria";
            Text = "GraficoCategoria";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox textBoxID;
        private TextBox textBoxCategoria;
        private TextBox textBoxDescripcion;
        private Button Guardar;
        private Button Volver;
        private DataGridView dataGridView1;
        private Button Refrescar;
    }
}