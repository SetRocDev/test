﻿using CapaDatos;
using CapaEntidades;
using CapaLogica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaGrafica
{
    public partial class GraficoCategoria : Form
    {
        public GraficoCategoria()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBoxID_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxCategoria_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBoxDescripcion_TextChanged(object sender, EventArgs e)
        {

        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            // Método para guardar
            try
            {
                int idCategoria;
                if (!int.TryParse(textBoxID.Text, out idCategoria))
                {
                    MessageBox.Show("Error al guardar la categoría: El Id de categoría debe ser un número entero.");
                    return;
                }

                string nombreCategoria = textBoxCategoria.Text;
                string descripcionCategoria = textBoxDescripcion.Text;

                ClaseCategoria categoria = new ClaseCategoria(idCategoria, nombreCategoria, descripcionCategoria);

                LogicaCategoria logica = new LogicaCategoria();
                logica.GuardarCategoria(categoria);
                limpiarInfo();

                // Para refrescar automaticamente
                List<ClaseCategoria> categorias = new List<ClaseCategoria>();

                for (int i = 0; i < Datos.ContadorCategoria; i++)
                {
                    categorias.Add(Datos.ArregloCategoria[i]);
                }

                dataGridView1.DataSource = categorias;

                MessageBox.Show("Categoría guardada correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la categoría: " + ex.Message);
            }
        }
        private void limpiarInfo()
        {
            textBoxID.Text = string.Empty;
            textBoxCategoria.Text = string.Empty;
            textBoxDescripcion.Text = string.Empty;
        }

        private void Volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void Refrescar_Click(object sender, EventArgs e)
        {
            List<ClaseCategoria> categorias = new List<ClaseCategoria>();

            for (int i = 0; i < Datos.ContadorCategoria; i++)
            {
                categorias.Add(Datos.ArregloCategoria[i]);
            }

            dataGridView1.DataSource = categorias;
        }
    }
}
