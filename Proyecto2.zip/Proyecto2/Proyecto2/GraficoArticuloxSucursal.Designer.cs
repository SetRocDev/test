﻿namespace CapaGrafica
{
    partial class GraficoArticuloxSucursal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            comboBoxSucursal = new ComboBox();
            dataGridViewArticulo = new DataGridView();
            textBoxCantidad = new TextBox();
            dataGridView1 = new DataGridView();
            Guardar = new Button();
            Volver = new Button();
            Refrescar = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewArticulo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(42, 24);
            label1.Name = "label1";
            label1.Size = new Size(63, 20);
            label1.TabIndex = 0;
            label1.Text = "Sucursal";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(36, 165);
            label2.Name = "label2";
            label2.Size = new Size(69, 20);
            label2.TabIndex = 1;
            label2.Text = "Cantidad";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(42, 63);
            label3.Name = "label3";
            label3.Size = new Size(61, 20);
            label3.TabIndex = 2;
            label3.Text = "Artículo";
            // 
            // comboBoxSucursal
            // 
            comboBoxSucursal.FormattingEnabled = true;
            comboBoxSucursal.Location = new Point(111, 21);
            comboBoxSucursal.Name = "comboBoxSucursal";
            comboBoxSucursal.Size = new Size(436, 28);
            comboBoxSucursal.TabIndex = 3;
            // 
            // dataGridViewArticulo
            // 
            dataGridViewArticulo.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewArticulo.Location = new Point(109, 55);
            dataGridViewArticulo.Name = "dataGridViewArticulo";
            dataGridViewArticulo.RowHeadersWidth = 51;
            dataGridViewArticulo.Size = new Size(438, 87);
            dataGridViewArticulo.TabIndex = 4;
            // 
            // textBoxCantidad
            // 
            textBoxCantidad.Location = new Point(109, 165);
            textBoxCantidad.Name = "textBoxCantidad";
            textBoxCantidad.Size = new Size(438, 27);
            textBoxCantidad.TabIndex = 5;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 208);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(776, 230);
            dataGridView1.TabIndex = 6;
            // 
            // Guardar
            // 
            Guardar.Location = new Point(615, 42);
            Guardar.Name = "Guardar";
            Guardar.Size = new Size(94, 29);
            Guardar.TabIndex = 7;
            Guardar.Text = "Guardar";
            Guardar.UseVisualStyleBackColor = true;
            Guardar.Click += Guardar_Click;
            // 
            // Volver
            // 
            Volver.Location = new Point(615, 91);
            Volver.Name = "Volver";
            Volver.Size = new Size(94, 29);
            Volver.TabIndex = 8;
            Volver.Text = "Volver";
            Volver.UseVisualStyleBackColor = true;
            Volver.Click += Volver_Click;
            // 
            // Refrescar
            // 
            Refrescar.Location = new Point(615, 139);
            Refrescar.Name = "Refrescar";
            Refrescar.Size = new Size(94, 29);
            Refrescar.TabIndex = 9;
            Refrescar.Text = "Refrescar";
            Refrescar.UseVisualStyleBackColor = true;
            Refrescar.Click += Refrescar_Click;
            // 
            // GraficoArticuloxSucursal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(Refrescar);
            Controls.Add(Volver);
            Controls.Add(Guardar);
            Controls.Add(dataGridView1);
            Controls.Add(textBoxCantidad);
            Controls.Add(dataGridViewArticulo);
            Controls.Add(comboBoxSucursal);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "GraficoArticuloxSucursal";
            Text = "GraficoArticuloxSucursal";
            Load += GraficoArticuloxSucursal_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridViewArticulo).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private ComboBox comboBoxSucursal;
        private DataGridView dataGridViewArticulo;
        private TextBox textBoxCantidad;
        private DataGridView dataGridView1;
        private Button Guardar;
        private Button Volver;
        private Button Refrescar;
    }
}