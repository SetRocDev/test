﻿using CapaDatos;
using CapaEntidades;
using CapaLogica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaGrafica
{
    public partial class GraficoArticuloxSucursal : Form
    {
        public GraficoArticuloxSucursal()
        {
            InitializeComponent();
        }

        private void GraficoArticuloxSucursal_Load(object sender, EventArgs e)
        {
            CargarSucursales();
            CargarArticulos();
            RefrescarInventario();
        }

        private void CargarSucursales()
        {
            var sucursalesActivas = Datos.ArregloSucursal.Where(s => s != null && s.ActivoSucursal).ToList();
            if (sucursalesActivas.Count == 0)
            {
                MessageBox.Show("No hay sucursales activas disponibles");
                return;
            }

            comboBoxSucursal.DisplayMember = "NombreSucursal";
            comboBoxSucursal.DataSource = sucursalesActivas;
        }

        private void CargarArticulos()
        {
            var articulosActivos = Datos.ArregloArticulo.Where(a => a != null && a.ActivoArticulo).ToList();
            if (articulosActivos.Count == 0)
            {
                MessageBox.Show("No hay artículos activos disponibles");
                return;
            }

            dataGridViewArticulo.DataSource = articulosActivos;
        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            try
            {
                ClaseSucursal? sucursal = comboBoxSucursal.SelectedItem as ClaseSucursal;
                if (sucursal == null)
                {
                    MessageBox.Show("Debe seleccionar una sucursal");
                    return;
                }

                if (!int.TryParse(textBoxCantidad.Text, out int cantidad) || cantidad <= 0)
                {
                    MessageBox.Show("La cantidad debe ser un número mayor a cero");
                    return;
                }

                if (dataGridViewArticulo.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Debe seleccionar al menos un artículo");
                    return;
                }

                foreach (DataGridViewRow row in dataGridViewArticulo.SelectedRows)
                {
                    ClaseArticulo? articulo = row.DataBoundItem as ClaseArticulo;
                    if (articulo != null)
                    {
                        if (Datos.ArregloInventario.Any(i => i != null &&
                            i.SucursalInventario.IdSucursal == sucursal.IdSucursal &&
                            i.ArticuloInventario.IdArticulo == articulo.IdArticulo))
                        {
                            MessageBox.Show($"El artículo {articulo.DescripcionArticulo} ya está asociado a esta sucursal");
                            continue;
                        }

                        ClaseArticuloxSucursal inventario = new ClaseArticuloxSucursal(sucursal, articulo, cantidad);
                        LogicaArticuloxSucursal logica = new LogicaArticuloxSucursal();
                        logica.GuardarArticuloxSucursal(inventario);
                    }
                }

                LimpiarCampos();
                RefrescarInventario();
                MessageBox.Show("Artículos asociados correctamente");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message);
            }
        }

        private void RefrescarInventario()
        {
            var inventario = Datos.ArregloInventario.Where(i => i != null).ToList();
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = inventario;
        }

        private void LimpiarCampos()
        {
            textBoxCantidad.Clear();
            dataGridViewArticulo.ClearSelection();
        }

        private void Volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Refrescar_Click(object sender, EventArgs e)
        {
            RefrescarInventario();
        }
    }
}
