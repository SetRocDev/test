﻿namespace CapaGrafica
{
    partial class GraficoSucursal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            textBoxID = new TextBox();
            textBoxNombre = new TextBox();
            textBoxTelefono = new TextBox();
            textBoxDireccion = new TextBox();
            comboBoxAdministrador = new ComboBox();
            comboBoxActivo = new ComboBox();
            Guardar = new Button();
            Volver = new Button();
            Refrescar = new Button();
            dataGridView1 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(92, 23);
            label1.Name = "label1";
            label1.Size = new Size(24, 20);
            label1.TabIndex = 0;
            label1.Text = "ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(52, 56);
            label2.Name = "label2";
            label2.Size = new Size(64, 20);
            label2.TabIndex = 1;
            label2.Text = "Nombre";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 88);
            label3.Name = "label3";
            label3.Size = new Size(104, 20);
            label3.TabIndex = 2;
            label3.Text = "Administrador";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(44, 122);
            label4.Name = "label4";
            label4.Size = new Size(72, 20);
            label4.TabIndex = 3;
            label4.Text = "Dirección";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(49, 155);
            label5.Name = "label5";
            label5.Size = new Size(67, 20);
            label5.TabIndex = 4;
            label5.Text = "Teléfono";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(65, 188);
            label6.Name = "label6";
            label6.Size = new Size(51, 20);
            label6.TabIndex = 5;
            label6.Text = "Activo";
            // 
            // textBoxID
            // 
            textBoxID.Location = new Point(122, 20);
            textBoxID.Name = "textBoxID";
            textBoxID.Size = new Size(334, 27);
            textBoxID.TabIndex = 6;
            // 
            // textBoxNombre
            // 
            textBoxNombre.Location = new Point(122, 53);
            textBoxNombre.Name = "textBoxNombre";
            textBoxNombre.Size = new Size(334, 27);
            textBoxNombre.TabIndex = 7;
            // 
            // textBoxTelefono
            // 
            textBoxTelefono.Location = new Point(122, 152);
            textBoxTelefono.Name = "textBoxTelefono";
            textBoxTelefono.Size = new Size(334, 27);
            textBoxTelefono.TabIndex = 8;
            // 
            // textBoxDireccion
            // 
            textBoxDireccion.Location = new Point(122, 119);
            textBoxDireccion.Name = "textBoxDireccion";
            textBoxDireccion.Size = new Size(334, 27);
            textBoxDireccion.TabIndex = 9;
            // 
            // comboBoxAdministrador
            // 
            comboBoxAdministrador.FormattingEnabled = true;
            comboBoxAdministrador.Location = new Point(122, 85);
            comboBoxAdministrador.Name = "comboBoxAdministrador";
            comboBoxAdministrador.Size = new Size(334, 28);
            comboBoxAdministrador.TabIndex = 10;
            // 
            // comboBoxActivo
            // 
            comboBoxActivo.FormattingEnabled = true;
            comboBoxActivo.Location = new Point(122, 185);
            comboBoxActivo.Name = "comboBoxActivo";
            comboBoxActivo.Size = new Size(334, 28);
            comboBoxActivo.TabIndex = 11;
            // 
            // Guardar
            // 
            Guardar.Location = new Point(569, 51);
            Guardar.Name = "Guardar";
            Guardar.Size = new Size(94, 29);
            Guardar.TabIndex = 12;
            Guardar.Text = "Guardar";
            Guardar.UseVisualStyleBackColor = true;
            Guardar.Click += Guardar_Click;
            // 
            // Volver
            // 
            Volver.Location = new Point(569, 98);
            Volver.Name = "Volver";
            Volver.Size = new Size(94, 29);
            Volver.TabIndex = 13;
            Volver.Text = "Volver";
            Volver.UseVisualStyleBackColor = true;
            Volver.Click += Volver_Click;
            // 
            // Refrescar
            // 
            Refrescar.Location = new Point(569, 151);
            Refrescar.Name = "Refrescar";
            Refrescar.Size = new Size(94, 29);
            Refrescar.TabIndex = 14;
            Refrescar.Text = "Refrescar";
            Refrescar.UseVisualStyleBackColor = true;
            Refrescar.Click += Refrescar_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 230);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(776, 208);
            dataGridView1.TabIndex = 15;
            // 
            // GraficoSucursal
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dataGridView1);
            Controls.Add(Refrescar);
            Controls.Add(Volver);
            Controls.Add(Guardar);
            Controls.Add(comboBoxActivo);
            Controls.Add(comboBoxAdministrador);
            Controls.Add(textBoxDireccion);
            Controls.Add(textBoxTelefono);
            Controls.Add(textBoxNombre);
            Controls.Add(textBoxID);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "GraficoSucursal";
            Text = "GraficoSucursal";
            Load += GraficoSucursal_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox textBoxID;
        private TextBox textBoxNombre;
        private TextBox textBoxTelefono;
        private TextBox textBoxDireccion;
        private ComboBox comboBoxAdministrador;
        private ComboBox comboBoxActivo;
        private Button Guardar;
        private Button Volver;
        private Button Refrescar;
        private DataGridView dataGridView1;
    }
}