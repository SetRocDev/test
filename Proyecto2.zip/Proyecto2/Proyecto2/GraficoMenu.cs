﻿using Proyecto2;

namespace CapaGrafica
{
    public partial class GraficoMenu : Form
    {
        public GraficoMenu()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void GraficoMenu_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Método para mostrar el formulario de admistrador
            GraficoAdministrador formulario = new GraficoAdministrador();
            formulario.ShowDialog();
        }

        private void btnCategoria_Click(object sender, EventArgs e)
        {
            // Método para mostrar el formulario de categoria
            GraficoCategoria formulario = new GraficoCategoria();
            formulario.ShowDialog();
        }

        private void btnArticulo_Click(object sender, EventArgs e)
        {
            // Método para mostrar el formulario de articulo
            GraficoArticulo formulario = new GraficoArticulo();
            formulario.ShowDialog();
        }

        private void btnCliente_Click(object sender, EventArgs e)
        {
            // Método para mostrar el formulario de cliente
            GraficoCliente formulario = new GraficoCliente();
            formulario.ShowDialog();
        }

        private void btnSucursal_Click(object sender, EventArgs e)
        {
            // Método para mostrar el formulario de sucursal
            GraficoSucursal formulario = new GraficoSucursal();
            formulario.ShowDialog();
        }

        private void btnArticuloxSucursal_Click(object sender, EventArgs e)
        {
            // Método para mostrar el formulario de Articulos x Sucursal
            GraficoArticuloxSucursal formulario = new GraficoArticuloxSucursal();
            formulario.ShowDialog();
        }
    }
}
