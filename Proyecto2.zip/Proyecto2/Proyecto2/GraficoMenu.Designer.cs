﻿namespace CapaGrafica
{
    partial class GraficoMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnCategoria = new Button();
            btnArticulo = new Button();
            btnAdministrador = new Button();
            btnCliente = new Button();
            btnSucursal = new Button();
            btnArticuloxSucursal = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(203, 37);
            label1.Name = "label1";
            label1.Size = new Size(400, 20);
            label1.TabIndex = 0;
            label1.Text = "Bienvenido(a), seleccione una funcionalidad para continuar";
            // 
            // btnCategoria
            // 
            btnCategoria.Location = new Point(326, 89);
            btnCategoria.Name = "btnCategoria";
            btnCategoria.Size = new Size(142, 45);
            btnCategoria.TabIndex = 1;
            btnCategoria.Text = "Categoría";
            btnCategoria.UseVisualStyleBackColor = true;
            btnCategoria.Click += btnCategoria_Click;
            // 
            // btnArticulo
            // 
            btnArticulo.Location = new Point(326, 140);
            btnArticulo.Name = "btnArticulo";
            btnArticulo.Size = new Size(142, 45);
            btnArticulo.TabIndex = 2;
            btnArticulo.Text = "Artículo";
            btnArticulo.UseVisualStyleBackColor = true;
            btnArticulo.Click += btnArticulo_Click;
            // 
            // btnAdministrador
            // 
            btnAdministrador.Location = new Point(326, 191);
            btnAdministrador.Name = "btnAdministrador";
            btnAdministrador.Size = new Size(142, 45);
            btnAdministrador.TabIndex = 3;
            btnAdministrador.Text = "Administrador";
            btnAdministrador.UseVisualStyleBackColor = true;
            btnAdministrador.Click += button3_Click;
            // 
            // btnCliente
            // 
            btnCliente.Location = new Point(326, 242);
            btnCliente.Name = "btnCliente";
            btnCliente.Size = new Size(142, 45);
            btnCliente.TabIndex = 4;
            btnCliente.Text = "Cliente";
            btnCliente.UseVisualStyleBackColor = true;
            btnCliente.Click += btnCliente_Click;
            // 
            // btnSucursal
            // 
            btnSucursal.Location = new Point(326, 293);
            btnSucursal.Name = "btnSucursal";
            btnSucursal.Size = new Size(142, 45);
            btnSucursal.TabIndex = 5;
            btnSucursal.Text = "Sucursal";
            btnSucursal.UseVisualStyleBackColor = true;
            btnSucursal.Click += btnSucursal_Click;
            // 
            // btnArticuloxSucursal
            // 
            btnArticuloxSucursal.Location = new Point(326, 344);
            btnArticuloxSucursal.Name = "btnArticuloxSucursal";
            btnArticuloxSucursal.Size = new Size(142, 50);
            btnArticuloxSucursal.TabIndex = 6;
            btnArticuloxSucursal.Text = "Articulo por Sucursal";
            btnArticuloxSucursal.UseVisualStyleBackColor = true;
            btnArticuloxSucursal.Click += btnArticuloxSucursal_Click;
            // 
            // GraficoMenu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnArticuloxSucursal);
            Controls.Add(btnSucursal);
            Controls.Add(btnCliente);
            Controls.Add(btnAdministrador);
            Controls.Add(btnArticulo);
            Controls.Add(btnCategoria);
            Controls.Add(label1);
            Name = "GraficoMenu";
            Text = "GraficoMenu";
            Load += GraficoMenu_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnCategoria;
        private Button btnArticulo;
        private Button btnAdministrador;
        private Button btnCliente;
        private Button btnSucursal;
        private Button btnArticuloxSucursal;
    }
}