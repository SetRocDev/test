﻿using CapaDatos;
using CapaEntidades;
using CapaLogica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaGrafica
{
    public partial class GraficoArticulo : Form
    {
        public GraficoArticulo()
        {
            InitializeComponent();
        }
        private void Guardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores de los campos de texto
                int idArticulo;
                if (!int.TryParse(textBoxID.Text, out idArticulo))
                {
                    MessageBox.Show("Error al guardar el artículo: El Id de artículo debe ser un número entero.");
                    return;
                }

                // Obtener los valores de los campos de texto
                string descripcionArticulo = textBoxDescripcion.Text ?? "";
                ClaseCategoria? categoriaArticulo = comboBoxCategoria.SelectedItem as ClaseCategoria;
                string marcaArticulo = textBoxMarca.Text ?? "";
                string activoArticuloTexto = comboBoxActivo.SelectedItem?.ToString() ?? "";

                if (activoArticuloTexto != "Si" && activoArticuloTexto != "No")
                {
                    MessageBox.Show("Error al guardar el artículo: Debe seleccionar un valor válido para el campo Activo.");
                    return;
                }

                bool activoArticulo = activoArticuloTexto == "Si";

                if (categoriaArticulo == null)
                {
                    MessageBox.Show("Error al guardar el artículo: Debe seleccionar una categoría.");
                    return;
                }

                ClaseArticulo articulo = new ClaseArticulo(idArticulo, descripcionArticulo, categoriaArticulo, marcaArticulo, activoArticulo);

                LogicaArticulo logica = new LogicaArticulo();
                logica.GuardarArticulo(articulo);
                // Metodo para limpiar automaticamente
                limpiarInfo();
                // Metodo para refrecar automaticamente
                List<ClaseArticulo> articulos = new List<ClaseArticulo>();

                for (int i = 0; i < Datos.ContadorArticulo; i++)
                {
                    articulos.Add(Datos.ArregloArticulo[i]);
                }

                dataGridView1.DataSource = articulos;

                MessageBox.Show("Artículo guardado correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar el artículo: " + ex.Message);
            }
        }

        private void Volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Refrescar_Click(object sender, EventArgs e)
        {
            List<ClaseArticulo> articulos = new List<ClaseArticulo>();

            for (int i = 0; i < Datos.ContadorArticulo; i++)
            {
                articulos.Add(Datos.ArregloArticulo[i]);
            }

            dataGridView1.DataSource = articulos;
        }

        private void GraficoArticulo_Load(object sender, EventArgs e)
        {
            {
                // Llenar el combobox de categoría artículo
                comboBoxCategoria.DisplayMember = "NombreCategoria";
                comboBoxCategoria.Items.Clear(); // Limpiar los elementos existentes
                foreach (ClaseCategoria categoria in Datos.ArregloCategoria)
                {
                    if (categoria != null)
                    {
                        comboBoxCategoria.Items.Add(categoria);
                    }
                }

                // Seleccionar el primer elemento por defecto
                if (comboBoxCategoria.Items.Count > 0)
                {
                    comboBoxCategoria.SelectedIndex = 0;
                }

                // Llenar el combobox de activo artículo
                comboBoxActivo.Items.Add("Si");
                comboBoxActivo.Items.Add("No");

                // Seleccionar el primer elemento por defecto
                if (comboBoxActivo.Items.Count > 0)
                {
                    comboBoxActivo.SelectedIndex = 0;
                }
            }
        }
        private void limpiarInfo()
        {
            textBoxID.Text = string.Empty;
            textBoxMarca.Text = string.Empty;
            textBoxDescripcion.Text = string.Empty;
            comboBoxCategoria.Text = string.Empty;
            comboBoxActivo.Text = string.Empty;
        }
    }
}
