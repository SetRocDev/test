﻿using CapaDatos;
using CapaEntidades;
using CapaLogica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace CapaGrafica
{
    public partial class GraficoSucursal : Form
    {
        public GraficoSucursal()
        {
            InitializeComponent();
        }

        private void GraficoSucursal_Load(object sender, EventArgs e)
        {
            // Verificar si el arreglo tiene datos
            if (Datos.ArregloAdministrador.Length == 0)
            {
                MessageBox.Show("No hay administradores en el arreglo");
            }

            // Llenar el combobox de administrador
            comboBoxAdministrador.DisplayMember = "NombreAdministrador";
            foreach (ClaseAdministrador categoria in Datos.ArregloAdministrador)
            {
                if (categoria != null)
                {
                    comboBoxAdministrador.Items.Add(categoria);
                }
            }

            // Seleccionar el primer elemento por defecto
            if (comboBoxAdministrador.Items.Count > 0)
            {
                comboBoxAdministrador.SelectedIndex = 0;
            }

            // Llenar el combobox de activo sucursal
            comboBoxActivo.Items.Add("Si");
            comboBoxActivo.Items.Add("No");

            // Seleccionar el primer elemento por defecto
            if (comboBoxActivo.Items.Count > 0)
            {
                comboBoxActivo.SelectedIndex = 0;
            }
        }

        private void Guardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Obtener los valores de los campos de texto
                int idSucursal;
                if (!int.TryParse(textBoxID.Text, out idSucursal))
                {
                    MessageBox.Show("Error al guardar la sucursal: El Id de sucursal debe ser un número entero.");
                    return;
                }

                // Obtener los valores de los campos de texto
                string nombreSucursal = textBoxNombre.Text ?? "";
                string direccionSucursal = textBoxDireccion.Text ?? "";
                string telefonoSucursal = textBoxTelefono.Text ?? "";

                // Verificar que todos los campos estén completos
                if (string.IsNullOrEmpty(nombreSucursal) || string.IsNullOrEmpty(direccionSucursal) || string.IsNullOrEmpty(telefonoSucursal))
                {
                    MessageBox.Show("Error al guardar la sucursal: Debe ingresar todos los campos.");
                    return;
                }
                // Obtener el administrador seleccionado
                ClaseAdministrador? administrador = comboBoxAdministrador.SelectedItem as ClaseAdministrador;

                // Obtener el valor del campo Activo
                string activoSucursalTexto = comboBoxActivo.SelectedItem?.ToString() ?? "";

                if (activoSucursalTexto != "Si" && activoSucursalTexto != "No")
                {
                    MessageBox.Show("Error al guardar la sucursal: Debe seleccionar un valor válido para el campo Activo.");
                    return;
                }

                bool activoSucursal = activoSucursalTexto == "Si";

                if (administrador == null)
                {
                    MessageBox.Show("Error al guardar la sucursal: Debe seleccionar un administrador.");
                    return;
                }

                ClaseSucursal sucursal = new ClaseSucursal(idSucursal, nombreSucursal, administrador, direccionSucursal, telefonoSucursal, activoSucursal);
                LogicaSucursal logica = new LogicaSucursal();
                logica.GuardarSucursal(sucursal);
                // Metodo para limpiar automaticamente
                limpiarInfo();
                // Metodo para refrescar el DGV automaticamente
                dataGridView1.DataSource = null;
                dataGridView1.DataSource = Datos.ArregloSucursal;
                dataGridView1.Refresh();

                MessageBox.Show("Sucursal guardada correctamente.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar la sucursal: " + ex.Message);
            }
        }

        private void Volver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Refrescar_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = Datos.ArregloSucursal;
            dataGridView1.Refresh();
        }

        private void limpiarInfo()
        {
            textBoxID.Text = string.Empty;
            textBoxNombre.Text = string.Empty;
            comboBoxAdministrador.Text = string.Empty;
            textBoxDireccion.Text = string.Empty;
            textBoxTelefono.Text = string.Empty;
            comboBoxActivo.Text = string.Empty;
        }
    }
}
